import requests
import wikipedia
from keybert import KeyBERT
import os
def google_text_search(search_term, api_key, cse_id, num=1):
    search_url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "q": search_term,
        "cx": cse_id,
        "key": api_key,
        "num": num
    }
    response = requests.get(search_url, params=params)
    return response.json()

def get_wikipedia_summary(keyword, sentences=20):
    try:
        # Get a detailed summary with the specified number of sentences
        summary = wikipedia.summary(keyword, sentences=sentences)
        return summary
    except wikipedia.DisambiguationError as e:
        return f"Disambiguation error: {e.options}"
    except wikipedia.PageError:
        return f"No page found for {keyword}"
    except Exception as e:
        return f"An error occurred: {str(e)}"
    
def google_search_image(search_term, api_key, cse_id, num=3):
    search_url = "https://www.googleapis.com/customsearch/v1"
    params = {
        "q": search_term,
        "cx": cse_id,
        "key": api_key,
        "searchType": "image",  
        "num": num
    }
    response = requests.get(search_url, params=params)
    return response.json()

def extract_keywords(text, num_keywords=10):
    kw_model = KeyBERT()
    keywords = kw_model.extract_keywords(text, keyphrase_ngram_range=(1, 2), stop_words='english', top_n=num_keywords)
    return [kw[0] for kw in keywords]

import uuid

def download_images(response_json, save_folder='images'):
    if not os.path.exists(save_folder):
        os.makedirs(save_folder)
    
    items = response_json.get('items')
    if not items:
        print("No images found.")
        return
    
    for idx, item in enumerate(items):
        image_url = item.get('link')
        if image_url:
            try:
                img_data = requests.get(image_url).content
                file_ext = image_url.split('.')[-1].split('?')[0]
                
                if len(file_ext) > 5 or '/' in file_ext:
                    file_ext = 'jpg'

                # Generate a unique filename using uuid
                unique_id = uuid.uuid4().hex[:8]  # short unique ID
                file_name = f'image_{unique_id}.{file_ext}'
                file_path = os.path.join(save_folder, file_name)
                
                with open(file_path, 'wb') as handler:
                    handler.write(img_data)
                    
                print(f"Downloaded: {file_path}")
            except Exception as e:
                print(f"Failed to download {image_url}. Reason: {e}")
