from PIL import Image, UnidentifiedImageError
from moviepy.editor import ImageClip, concatenate_videoclips, AudioFileClip
import numpy as np
import os
def generate_video():
    images_folder = 'images'
    audio_file = 'static/summary.mp3'

    image_files = sorted([
        os.path.join(images_folder, img)
        for img in os.listdir(images_folder)
        if img.lower().endswith(('.png', '.jpg', '.jpeg', '.webp'))
    ])

    audio = AudioFileClip(audio_file)
    audio_duration = audio.duration

    valid_clips = []

    num_images = len(image_files)
    if num_images == 0:
        raise Exception("No images found in the folder.")

    image_duration = audio_duration / num_images

    for img_path in image_files:
        try:
            img_pil = Image.open(img_path).convert('RGB')
            img_np = np.array(img_pil)
            clip = ImageClip(img_np).set_duration(image_duration).resize(height=720)
            valid_clips.append(clip)
            print(f"Added image: {img_path}")
        except UnidentifiedImageError:
            print(f"Skipped invalid image: {img_path}")
        except Exception as e:
            print(f"Error processing {img_path}: {e}")

    if not valid_clips:
        raise Exception("No valid images found to create a video.")

    video = concatenate_videoclips(valid_clips, method="compose")

    # Attach audio and match duration explicitly
    video = video.set_audio(audio)
    video = video.set_duration(audio.duration)

    video.write_videofile(
        "static/output_video.mp4",
        fps=24,
        codec='libx264',
        audio_codec='aac'
    )
    folder = 'images'
    if os.path.exists(folder):
        for f in os.listdir(folder):
            file_path = os.path.join(folder, f)
            if os.path.isfile(file_path):
                os.remove(file_path)

